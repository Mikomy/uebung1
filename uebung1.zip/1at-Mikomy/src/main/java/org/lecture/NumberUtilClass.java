package org.lecture;

import java.util.regex.Pattern;

public class NumberUtilClass {

    /**
     * Copied from Barbara Sach-Lackner windwofrce
     * Tries to parse a double frm given value;
     * @param value the value to be parsed
     * @return the value as Double or null, if the value is not parsable
     */
    public static Double parseDouble(String value) {

        if (value.contains(",") || value.contains(".")) {
            value = value.replace(",", ".");
            Pattern compile = Pattern.compile("\\d+\\.\\d+");
            if (value.matches(compile.pattern())) {
                return Double.parseDouble(value);
            }
        } else if (!value.isBlank()) {
            return Double.parseDouble(value);
        }
        return null;

    }

    /**
     * Tries to parse an integer frm given value;
     * @param value the value to be parsed
     * @return the value as Integer or -1, if the value is not parsable
     */
    public static int parseInt(String value) {
        Pattern compile = Pattern.compile("^[0-9]+$");
        if (value.matches(compile.pattern())) {
            return Integer.parseInt(value);
        }
        return -1;
    }
}
