package org.lecture;

import lombok.extern.slf4j.Slf4j;

import java.util.Scanner;

@Slf4j
public class NumberSystemConverterMenu {
    private Scanner scanner = new Scanner(System.in);
    private CalculatorRAM calculatorRAM;
    private Calculate calculate = new Calculate();
    public NumberSystemConverterMenu(CalculatorRAM calculatorRAM) {this.calculatorRAM = calculatorRAM;}
    public void runMenu() {

        String menu = """
                
                1 - Enter  - number        2 -   Select           3 - Select           === 9 - calculate  
                  a Number   system            an Operation           3.Part
                """;
        scanner = new Scanner(System.in);
        calculatorRAM.createInput0(calculatorRAM);
        boolean loop = true;
        System.out.println("Welcom to the Number Converter!");
        while (loop) {
            System.out.println(menu);
            calculatorRAM.printCalculatorRAM();
            String input = scanner.nextLine();

            switch (input) {
                case "1" -> {
                    log.debug("Enter a number");
                    EnterInput.enterNumber(calculatorRAM);
                }
                case "2" -> {
                    log.debug("Select an operation");
                    EnterInput.enterOperation(calculatorRAM);
                }
                case "3" -> {
                    log.debug("Enter the 3.part");
                    EnterInput.enter3PArt(calculatorRAM);
                }
                case "9" -> {
                    log.debug("calculate");
                    calculate.calculate(calculatorRAM);
                }
                default -> throw new IllegalStateException("Unexpected value: " + input);
            }
        }

    }

}
