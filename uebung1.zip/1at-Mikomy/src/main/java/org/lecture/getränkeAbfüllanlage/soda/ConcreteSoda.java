package org.lecture.getränkeAbfüllanlage.soda;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConcreteSoda implements SodaFactory {
    @Override
    public SodaGetränk createSoda(SodaType type) {
        SodaGetränk product = null;
        switch (type) {
            case SODA -> {
                log.debug("Creating Product");
                product = new Soda();
            }
            default -> {
                log.error("Unknown Product" + product);
            }
        }
        return product;
    }
}
