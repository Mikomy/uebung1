package org.lecture.getränkeAbfüllanlage.cola;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Slf4j
public enum ColaType {
    COLA("Soda", "21"),
    COLA_ZUCKERFREI("Soda zuckerfrei", "22");

    ColaType(String name, String orderCode) {
        this.name = name;
        this.orderCode = orderCode;
    }

    private final String name;
    private final String orderCode;

    public String getName() {
        return name;
    }
    public  String getOrderCode() {

        return orderCode;
    }
    public static ColaType checkProductType2(String orderCode) {
        var productType = Arrays.stream(ColaType.values())
                .filter(product -> product.getOrderCode().equalsIgnoreCase(orderCode))
                .findFirst();
        ColaType type = null;
        if (productType.isPresent()) {
            type = productType.get();
        }
        return type;
    }
}
