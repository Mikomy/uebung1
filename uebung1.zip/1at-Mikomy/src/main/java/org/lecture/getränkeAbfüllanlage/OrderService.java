package org.lecture.getränkeAbfüllanlage;

import lombok.extern.slf4j.Slf4j;
import org.lecture.getränkeAbfüllanlage.file.FileHandler;
import org.lecture.getränkeAbfüllanlage.orangenSaft.ConcreteOrangen;
import org.lecture.getränkeAbfüllanlage.orangenSaft.OrangenFactory;
import org.lecture.getränkeAbfüllanlage.orangenSaft.OrangenGetränke;
import org.lecture.getränkeAbfüllanlage.orangenSaft.OrangenType;
import org.lecture.getränkeAbfüllanlage.soda.ConcreteSoda;
import org.lecture.getränkeAbfüllanlage.soda.SodaFactory;
import org.lecture.getränkeAbfüllanlage.soda.SodaGetränk;
import org.lecture.getränkeAbfüllanlage.soda.SodaType;
import org.lecture.getränkeAbfüllanlage.zitrone.ConcreteZitronen;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenFactory;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenGetränke;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenType;
import org.lecture.getränkeAbfüllanlage.cola.ConcreteCola;
import org.lecture.getränkeAbfüllanlage.cola.ColaFactory;
import org.lecture.getränkeAbfüllanlage.cola.ColaGetränke;
import org.lecture.getränkeAbfüllanlage.cola.ColaType;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

@Slf4j
public class OrderService {
    private Scanner scanner = new Scanner(System.in);

    private OrderUtility orderUtility = new OrderUtility(scanner);
    private OrderBook orderBook;
    public OrderService(OrderBook orderBook) { this.orderBook = orderBook; }
    private ZitronenFactory zitronenFactory = new ConcreteZitronen();
    private ColaFactory colaFactory = new ConcreteCola();
    private OrangenFactory orangenFactory = new ConcreteOrangen();
    private SodaFactory sodaFactory = new ConcreteSoda();

/*
 Executes the main functionality of the order service by displaying a menu and handling user input.
 */
    public void run() throws InterruptedException, IOException {

        String menu = """
                                
                1 - Enter location
                --------------------------------
                2 - Show available products
                3 - Enter order
                --------------------------------
                5 - Cancel order
                -------------------------------- 
                7 - Save orders in file
                --------------------------------
                8 - Display order and Calculate costs
                --------------------------------
                9 - Send order
                
                0 - exit
                                
                """;

        scanner = new Scanner(System.in);
        boolean loop = true;
        System.out.println("Welcome to \"'Factory\"!");
        while (loop) {
            System.out.println(menu);

            String input = scanner.nextLine();

            switch (input) {
                case "1" -> {
                    log.debug("Set destination selected");
                    enterDeliveryCity();
                }
                case "2" -> {
                    log.debug("Show the available products - selected");
                    showAvailableProducts();
                }
                case "3" -> {
                    log.debug("Enter the order on the console - selected");
                    orderUtility.setOrderProperties(orderBook);
                }

                case "5" -> {
                    log.debug("Remove an item from the order list - selected");
                    orderUtility.removeItemOfOrderList(orderBook);
                }
            //    case "6" -> {
               //     log.debug("");
              //  }
                case "7" -> {
                    log.debug("Save the order - selected");
                    saveFile(orderBook);
                }
                case "8" -> {
                    log.debug("Display the order - selected");
                    orderBook.showOrder();
                    orderBook.printCosts();
                }
                case "9" -> {
                    log.debug("deliver the order - selected");
                    orderUtility.deliver(orderBook);
                }
                case "0" -> loop = false;
            }
        }
    }

    private void saveFile(OrderBook orderBook) throws IOException {
        Path path = Paths.get("src/main/resources/exam/");
        FileHandler fh = new FileHandler();
       fh.saveOrdersInFile(orderBook, path );
    }

    /*
     Imports orders from a file and adds them to the order book.
     */


/*
 Reads the orders from a file using the FileHandler class and adds them to the order book.
 */



/*
Generates an ID for an order in the order book.
 */


/*
Prompts the user to enter the delivery city for the order and sets it in the order book.
 */
    private void enterDeliveryCity() {
        String input;
        Destination destination;
        System.out.println("Dear customer, where would you like your order to be delivered to?");
        do{
            Arrays.stream(Destination.values())
                    .forEach(dest -> System.out.println(dest.getId() +  " " + dest.getName()));

            // Arrays.stream(Destination.values()).toList().forEach(System.out::println);
            destination = getDestination();
        } while (destination == null);
        System.out.printf("You can get your order there: %s", destination);
        orderBook.setDestination(destination);
    }

    /*
    Retrieves the selected destination from the user input.
     */
    private Destination getDestination() {
        String destinationInput = scanner.nextLine().toUpperCase();
        Destination destination = Destination.getDestination(destinationInput);
        return destination;
    }

    /*
    Displays the available products and their details to the user.
     */
    public void showAvailableProducts() {
        System.out.println("~".repeat(120));
        System.out.format("%s Available Drinks %s%n", "-".repeat(48), "-".repeat(48));
        System.out.format("%-25s %-20s %-60s %-20s %n", "Beverage", "Label", "Price","kcal");
        for (ZitronenType pr1 : ZitronenType.values()) {
            ZitronenGetränke available1  = getItemData(pr1);
            System.out.format("%-25s %-60s %-20s %-20s %n",
                    pr1,available1.getEtikett(),available1.getPrice(),available1.getKcal());
        }
        for (ColaType pr2 : ColaType.values()) {
            ColaGetränke available2 = getItem2Data(pr2);
            System.out.format("%-25s %-60s %-20s %-20s %n",
                    pr2,available2.getEtikett(),available2.getPrice(),available2.getKcal());
        }
        for (OrangenType pr3 : OrangenType.values()) {
            OrangenGetränke available3 = getItem3Data(pr3);
            System.out.format("%-25s %-60s %-20s %-20s %n",
                    pr3,available3.getEtikett(),available3.getPrice(),available3.getKcal());
        }
        for (SodaType pr4 : SodaType.values()) {
            SodaGetränk available4 = getItem4Data(pr4);
            System.out.format("%-25s %-60s %-20s %-20s %n",
                    pr4,available4.getEtikett(),available4.getPrice(),available4.getKcal());
        }
        System.out.println("~".repeat(120));
    }

    private SodaGetränk getItem4Data(SodaType pr4) {
        return switch (pr4) {
            case SODA -> sodaFactory.createSoda(SodaType.SODA);
        };
    }
    private OrangenGetränke getItem3Data(OrangenType pr3) {
        return switch (pr3) {
            case ORANGENSAFT -> orangenFactory.createOrangenGetränk(OrangenType.ORANGENSAFT);
            case ORANGENSAFT_ZUCKERFREI -> orangenFactory.createOrangenGetränk(OrangenType.ORANGENSAFT_ZUCKERFREI);
        };
    }

    /*
    Returns an instance of the appropriate subclass
     */
    private ColaGetränke getItem2Data(ColaType pr2) {
        return switch (pr2) {
            case COLA -> colaFactory.createColaGetränk(ColaType.COLA);
            case COLA_ZUCKERFREI -> colaFactory.createColaGetränk(ColaType.COLA_ZUCKERFREI);
        };

    }

    private ZitronenGetränke getItemData(ZitronenType pr1) {
       return switch (pr1) {
            case ZITRONE -> zitronenFactory.createZitronenGetränke(ZitronenType.ZITRONE);
            case ZITRONE_ZUCKERFREI -> zitronenFactory.createZitronenGetränke(ZitronenType.ZITRONE_ZUCKERFREI);
        };
    }
}

