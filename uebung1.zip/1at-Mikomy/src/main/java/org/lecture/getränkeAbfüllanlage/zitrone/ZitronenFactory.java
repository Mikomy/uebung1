package org.lecture.getränkeAbfüllanlage.zitrone;

/**
 * The Factory Method Interface for creating Products
 */
public interface ZitronenFactory {
    /**
     * Creates a Product according to given type
     * @param type the Product type
     */
    ZitronenGetränke createZitronenGetränke(ZitronenType type);

}
