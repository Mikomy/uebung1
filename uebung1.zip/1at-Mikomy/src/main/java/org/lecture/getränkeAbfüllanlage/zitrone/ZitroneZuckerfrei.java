package org.lecture.getränkeAbfüllanlage.zitrone;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@Slf4j
@Getter
public class ZitroneZuckerfrei extends ZitronenGetränke {

   public ZitroneZuckerfrei() {
       this.etikett = "Sauer macht lustig!";
       this.kcal = SumKcal();
       this.hasWasser = true;
       this.pfand = new BigDecimal("0.2");
       this.price = new BigDecimal("0.99");
       this.hasKohlensäure = false;
       this.hasZucker = true;
       this.hasZitronenSaftKonzentrat = true;

   }

    private double SumKcal() {
        int sum = 0;
        int zucker = 30;
        int zitronenSaftKonzentrat = 5;
        int colaSirup = 150;
        int orangenSaft = 235;
        if (hasZucker = true) {
            sum += zucker;
        }
        if (hasZitronenSaftKonzentrat = true) {
            sum += zitronenSaftKonzentrat;
        }
        return sum;
    }
/*
    @Override
    public void orderProduct() throws InterruptedException {
        log.info("Preparing ...");
        super.orderProduct();
        log.info(" created");
    }

 */
}
