package org.lecture.getränkeAbfüllanlage.orangenSaft;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Slf4j
public enum OrangenType {
    ORANGENSAFT("Orangensaft", "31"),
    ORANGENSAFT_ZUCKERFREI("Orangen zuckerfrei", "32");

    OrangenType(String name, String orderCode) {
        this.name = name;
        this.orderCode = orderCode;
    }

    private final String name;
    private final String orderCode;

    public String getName() {
        return name;
    }
    public  String getOrderCode() {

        return orderCode;
    }
    public static OrangenType checkProductType2(String orderCode) {
        var productType = Arrays.stream(OrangenType.values())
                .filter(product -> product.getOrderCode().equalsIgnoreCase(orderCode))
                .findFirst();
        OrangenType type = null;
        if (productType.isPresent()) {
            type = productType.get();
        }
        return type;
    }
}
