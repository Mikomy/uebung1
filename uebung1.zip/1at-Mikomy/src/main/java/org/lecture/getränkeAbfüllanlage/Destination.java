package org.lecture.getränkeAbfüllanlage;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Optional;

@Slf4j
public enum Destination {
    BIS_3KM("1", "Sie sind in 3km entfernt von Getränke Shop", 1, new BigDecimal("0.0")),
    BIS_7KM("2", "Sie sind in 7km entfernt von Getränke Shop", 7, new BigDecimal("2.0")),
    AB_12KM("3", "Sie sind mehr als 12km entfernt von Getränke Shop", 12, new BigDecimal("5.0")),
    SELF_DELIVERY("4", "Self-delivery", 0, new BigDecimal("0.0"));

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getDistance() {
        return distance;
    }

    public BigDecimal getPrice() {
        return price;
    }

    private final String id;
    private final String name;
    private final int distance;
    private final BigDecimal price;

    Destination(String i, String name, int distance, BigDecimal price) {
        this.id = i;
        this.name = name;
        this.distance = distance;
        this.price = price;
    }


    public static Destination getDestination(String destinationInput) {
        Destination destination = null;
        Optional<Destination> dest = Arrays.stream(Destination.values())
                .filter(d -> d.getName().equalsIgnoreCase(destinationInput) || d.getId().equalsIgnoreCase(destinationInput))
                .findAny();
        if (dest.isEmpty()) {
            log.error("Destination not found: " + destinationInput);
            System.out.println("Not a valid Destination. Please enter again.");
        } else {
            destination = dest.get();
        }
        return destination;
    }
}
