package org.lecture.getränkeAbfüllanlage.orangenSaft;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@Slf4j
@Getter
public class Orangen extends OrangenGetränke {

    public Orangen() {
        this.etikett = "Hätte ich Kohlensäure, wäre soviel Frucht nicht zu fassen";
        this.kcal = SumKcal();
        this.hasWasser = true;
        this.pfand = new BigDecimal("0.2");
        this.price = new BigDecimal("1.15");
        this.hasZucker = true;
        this.hasOrangensaft = true;

    }

    private double SumKcal() {
        int sum = 0;
        int zucker = 30;
        int zitronenSaftKonzentrat = 5;
        int colaSirup = 150;
        int orangenSaft = 235;
        if (hasZucker = true) {
            sum += zucker;
        }
        if (hasOrangensaft = true) {
            sum += orangenSaft;
        }
        return sum;
    }
/*
    @Override
    public void orderProduct() throws InterruptedException {
        log.info("Preparing ...");
        super.orderProduct();
        log.info(" created");
    }

 */
}

