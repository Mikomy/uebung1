package org.lecture.getränkeAbfüllanlage.file;

import java.util.Arrays;

public enum ProductType {
    ZITRONE("Zitrone", "11"),
    ZITRONE_ZUCKERFREI("Zitrone zuckerfrei", "12"),
    COLA("Cola", "21"),
    COLA_ZUCKERFREI("Cola zuckerfrei", "22"),
    ORANGENSAFT("Orangensaft", "31"),
    ORANGENSAFT_ZUCKERFREI("Orangen zuckerfrei", "32"),
    SODA("Soda", "41");

    ProductType(String name, String orderCode) {
        this.name = name;
        this.orderCode = orderCode;
    }

    private final String name;
    private final String orderCode;

    public String getName() {
        return name;
    }
    public  String getOrderCode() {

        return orderCode;
    }
    public static ProductType checkProductType(String input) {
        var productType = Arrays.stream(ProductType.values())
                .filter(product -> product.name().equalsIgnoreCase(input) || product.getOrderCode().equalsIgnoreCase(input))
                .findFirst();
        ProductType type = null;
        if (productType.isPresent()) {
            type = productType.get();
        }
        return type;
    }
}
