package org.lecture.getränkeAbfüllanlage.zitrone;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Slf4j
public enum ZitronenType {
    ZITRONE("Zitrone", "11"),
    ZITRONE_ZUCKERFREI("Zitrone zuckerfrei", "12");


    ZitronenType(String name, String orderCode) {
        this.name = name;
        this.orderCode = orderCode;
    }

    private final String name;
    private final String orderCode;

    public String getName() {
        return name;
    }
    public  String getOrderCode() {

        return orderCode;
    }
    public static ZitronenType checkProductType1(String orderCode) {
        var productType = Arrays.stream(ZitronenType.values())
                .filter(product -> product.getOrderCode().equalsIgnoreCase(orderCode))
                .findFirst();
        ZitronenType type = null;
        if (productType.isPresent()) {
            type = productType.get();
        }
        return type;
    }
}
