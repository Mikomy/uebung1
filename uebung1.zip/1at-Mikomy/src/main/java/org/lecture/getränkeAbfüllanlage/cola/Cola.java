package org.lecture.getränkeAbfüllanlage.cola;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@Slf4j
@Getter
public class Cola extends ColaGetränke {

    public Cola() {
        this.etikett = "Born in the USA";
        this.kcal = SumKcal();
        this.hasWasser = true;
        this.pfand = new BigDecimal("0.2");
        this.price = new BigDecimal("1.50");
        this.hasKohlensäure = true;
        this.hasZucker = true;
        this.hasColaSirup = true;

    }

    private double SumKcal() {
        int sum = 0;
        int zucker = 30;
        int zitronenSaftKonzentrat = 5;
        int colaSirup = 150;
        int orangenSaft = 235;
        if (hasZucker = true) {
            sum += zucker;
        }
        if (hasColaSirup = true) {
            sum += colaSirup;
        }
        return sum;
    }
/*
    @Override
    public void orderProduct() throws InterruptedException {
        log.info("Preparing ...");
        super.orderProduct();
        log.info(" created");
    }

 */
}

