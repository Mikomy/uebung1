package org.lecture.getränkeAbfüllanlage.soda;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@Slf4j
@Getter
public class Soda extends SodaGetränk {

    public Soda() {
        this.etikett = "Born in the USA";
        this.kcal = 0.0;
        this.hasWasser = true;
        this.pfand = new BigDecimal("0.2");
        this.price = new BigDecimal("0.50");
        this.hasKohlensäure = true;

    }


/*
    @Override
    public void orderProduct() throws InterruptedException {
        log.info("Preparing ...");
        super.orderProduct();
        log.info(" created");
    }

 */
}

