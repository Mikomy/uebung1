package org.lecture.getränkeAbfüllanlage.soda;

public interface SodaFactory {
    SodaGetränk createSoda(SodaType type);

}
