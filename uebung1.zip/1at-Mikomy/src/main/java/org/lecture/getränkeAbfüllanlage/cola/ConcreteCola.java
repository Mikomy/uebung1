package org.lecture.getränkeAbfüllanlage.cola;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConcreteCola implements ColaFactory {
    @Override
    public ColaGetränke createColaGetränk(ColaType type) {
        ColaGetränke product = null;
        switch (type) {
            case COLA -> {
                log.debug("Creating Product");
                product = new Cola();
            }
            case COLA_ZUCKERFREI -> {
                log.debug("Creating Product");
                product = new ColaZuckerfrei();
            }
            default -> {
                log.error("Unknown Product" + product);
            }
        }
        return product;
    }
}
