package org.lecture.getränkeAbfüllanlage;

import lombok.extern.slf4j.Slf4j;
import org.lecture.getränkeAbfüllanlage.file.ProductType;
import org.lecture.getränkeAbfüllanlage.orangenSaft.ConcreteOrangen;
import org.lecture.getränkeAbfüllanlage.orangenSaft.OrangenFactory;
import org.lecture.getränkeAbfüllanlage.orangenSaft.OrangenType;
import org.lecture.getränkeAbfüllanlage.soda.ConcreteSoda;
import org.lecture.getränkeAbfüllanlage.soda.SodaFactory;
import org.lecture.getränkeAbfüllanlage.soda.SodaType;
import org.lecture.getränkeAbfüllanlage.zitrone.ConcreteZitronen;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenFactory;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenType;
import org.lecture.getränkeAbfüllanlage.cola.ConcreteCola;
import org.lecture.getränkeAbfüllanlage.cola.ColaFactory;
import org.lecture.getränkeAbfüllanlage.cola.ColaType;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

@Slf4j
public class OrderUtility {
    private Scanner scanner;

    private ZitronenFactory zitronenFactory = new ConcreteZitronen();
    private ColaFactory colaFactory = new ConcreteCola();
    private OrangenFactory orangenFactory = new ConcreteOrangen();
    private SodaFactory sodaFactory = new ConcreteSoda();

    private OrderBook orderBook;
    private OrderService orderService;

    public OrderUtility(Scanner scanner) {
        this.scanner = scanner;
    }
/*
allows the user to remove an item from the order list
 */
    public void removeItemOfOrderList(OrderBook orderBook) {
        System.out.println("Order List:");
        System.out.println("------------------------------------------");

        orderBook.showOrder();

            System.out.println("------------------------------------------");

            System.out.println("Enter the index of the item you want to remove:");
            String remId = scanner.nextLine();


        try {
            int orderId = Integer.parseInt(remId);
            Order removedItem = orderBook.remove(orderId);
            if (removedItem == null) {
                System.out.println("Item not found.");
            } else {
                System.out.printf("Removed %s from the order.%n", removedItem);
            }
        } catch (NumberFormatException e) {
            System.out.printf("Invalid input: %s. Ignoring.%n", remId);
        }

        System.out.println("------------------------------------------");
    }


/*
sets the properties for a new order
 */
    public void setOrderProperties(OrderBook orderBook) {
        //Orderable orderable = null;
        Order.OrderBuilder orderBuilder = new Order.OrderBuilder();
        orderBuilder.withId(orderMapId(orderBook));
        buildProduct(orderBuilder);
        orderBuilder.withOrderAmount(getOrderAmount());
        orderBuilder.withOrderDate(LocalDate.now());
        Order order = orderBuilder.build();
        int count = orderBook.size() + 1;
        orderBook.add(count, order);
    }

    private Integer orderMapId(OrderBook orderBook) {
        int count = orderBook.size() + 1;
        return count;
    }
/*
the user enter the order codes of the products they want to order
 */
    private void buildProduct(Order.OrderBuilder orderBuilder) {
        System.out.println("Enter the order codes of the product you want to order: ");
        Arrays.stream(ZitronenType.values()).forEach(productType1 -> System.out.println(productType1.getOrderCode() + " " + productType1.getName()));
        Arrays.stream(ColaType.values()).forEach(cola -> System.out.println(cola.getOrderCode() + " " + cola.getName()));
        Arrays.stream(OrangenType.values()).forEach(orangen -> System.out.println(orangen.getOrderCode() + " " + orangen.getName()));
        Arrays.stream(SodaType.values()).forEach(soda -> System.out.println(soda.getOrderCode() + " " + soda.getName()));

        String input = scanner.nextLine();
        String[] orderCodes = input.split(",");
        for (String orderCode : orderCodes) {
            var foundProduct = ProductType.checkProductType(orderCode);
            if (foundProduct == null) {
                System.err.printf("Invalid type %s %n", orderCode);
            }
            orderBuilder.withProduct(getFactory(foundProduct));
        }
    }
    /*
    user enter the quantity they want to order for the selected product
     */
    private int getOrderAmount() {
        System.out.println("Please enter how many you want to order of the selected product");
        String numberOfEntries = scanner.nextLine();
        //scanner.nextLine();

        int value = NumberUtilClass.parseInt(numberOfEntries);
        if (value < 0) {
            System.err.println("Not all field are set: " + value);
            log.error("Not all field are set: " + value);
        } else {
            return value;
        }
        return 0;
        }


private Getränke getFactory (ProductType type){
        return switch (type) {
        case ZITRONE -> zitronenFactory.createZitronenGetränke(ZitronenType.ZITRONE);
        case ZITRONE_ZUCKERFREI -> zitronenFactory.createZitronenGetränke(ZitronenType.ZITRONE_ZUCKERFREI);
        case COLA -> colaFactory.createColaGetränk(ColaType.COLA);
        case COLA_ZUCKERFREI -> colaFactory.createColaGetränk(ColaType.COLA_ZUCKERFREI);
        case ORANGENSAFT -> orangenFactory.createOrangenGetränk(OrangenType.ORANGENSAFT);
        case ORANGENSAFT_ZUCKERFREI -> orangenFactory.createOrangenGetränk(OrangenType.ORANGENSAFT_ZUCKERFREI);
        case SODA -> sodaFactory.createSoda(SodaType.SODA);
        };
        }

    public void deliver(OrderBook orderBook) throws InterruptedException {
        System.out.println("Would you like to finalise or cancel your order? ( y )finalise/cancel( n )");
        Destination destination = orderBook.getDestination();
        do {
            String choice = scanner.nextLine().toLowerCase();
            if (choice.equals("y")) {
                System.out.println("You ordered: ");
                orderBook.printCosts();
                produceProducts(orderBook);
                System.out.println("Thank you for choosing \"Mike Beverage shop\"!");
                System.out.println("Your order will bee delivered only if the sum of the beverages are minimum 12");
                break;
            } else if (choice.equals("n")) {
                System.out.println("you can continue with your order");
                break;
            } else {
                log.error("Selection not found " + choice);
                System.out.println("Please try again. Available options are finalise and cancel");

            }
        } while (true);
    }

    private void produceProducts(OrderBook orderBook) throws InterruptedException {

        System.out.println("Your order is being prepared...");
        System.out.println("Packaging your order...");
        log.debug("Waiting for 2 seconds");
        TimeUnit.SECONDS.sleep(2);
        System.out.printf("You'll receive your order%n");
        orderBook.getOrderMap().clear();
    }
}