package org.lecture.getränkeAbfüllanlage;

import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;

@ToString
@Getter
public abstract class Getränke implements Orderable{
    protected String etikett;
    protected double kcal;
    protected BigDecimal price;
    protected BigDecimal pfand;



    /*
    @Override
    public void orderProduct() throws InterruptedException {
      //  TimeUnit.SECONDS.wait((long) (minutesToCreate*0.25));
    }
 */

}
