package org.lecture.getränkeAbfüllanlage.cola;

import lombok.Getter;
import org.lecture.getränkeAbfüllanlage.Getränke;

@Getter
public abstract class ColaGetränke extends Getränke {
    protected boolean hasWasser;
    protected boolean hasKohlensäure;
    protected boolean hasZucker;
    protected boolean hasColaSirup;

}
