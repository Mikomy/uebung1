package org.lecture.getränkeAbfüllanlage.orangenSaft;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConcreteOrangen implements OrangenFactory {
    @Override
    public OrangenGetränke createOrangenGetränk(OrangenType type) {
        OrangenGetränke product = null;
        switch (type) {
            case ORANGENSAFT -> {
                log.debug("Creating Product");
                product = new Orangen();
            }
            case ORANGENSAFT_ZUCKERFREI -> {
                log.debug("Creating Product");
                product = new OrangenZuckerfrei();
            }
            default -> {
                log.error("Unknown Product" + product);
            }
        }
        return product;
    }
}
