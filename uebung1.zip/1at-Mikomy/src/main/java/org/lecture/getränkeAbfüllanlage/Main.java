package org.lecture.getränkeAbfüllanlage;

import java.io.IOException;

public class Main {

    /**
     * @author Miklos Komlosy
     *
     * * I used the exempleExam, the event, the junkfood, the News-Service ,the Windforce,the Cashbook,
     * the "Einheit 6-7-8 Musterbeispiele" codes from Barbara Sach-Lackner
     *  to write my task
     *
     * This program is an order service.
     * From the menu you can choose and order products .
     * you can also import orders from files.
     * All costs are calculated.
     *
     */
    private static final OrderBook orderBook = new OrderBook();

    public static void main(String[] args) throws InterruptedException, IOException {
    OrderService service = new OrderService(orderBook);
    service.run();

    }
}
