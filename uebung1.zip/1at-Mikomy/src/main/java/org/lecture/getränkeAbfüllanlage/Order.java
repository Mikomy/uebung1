package org.lecture.getränkeAbfüllanlage;

import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;


@Getter
@ToString
public class Order {
    private final Integer id;
    private final Getränke product;
    private final Integer orderAmount;
    private final LocalDate orderDate;

    private Order(OrderBuilder orderBuilder) {
        this.id = orderBuilder.id;
        this.product = orderBuilder.product;
        this.orderAmount = orderBuilder.orderAmount;
        this.orderDate = orderBuilder.orderDate;
    }

    private Order(int id, Getränke product, int orderAmount, LocalDate orderDate) {
        this.id = id;
        this.product = product;
        this.orderAmount = orderAmount;
        this.orderDate = orderDate;
    }


    public BigDecimal calculateOrderCost() {
        return new BigDecimal(orderAmount).multiply(product.getPrice());
    }
    public BigDecimal calculatePfandCost() {
        return new BigDecimal(orderAmount).multiply(product.getPfand());
    }

    public static class OrderBuilder {
    private Integer id;
    private Getränke product;
    private Integer orderAmount;
    private LocalDate orderDate;

    public OrderBuilder withId(int id) {
        this.id = id;
        return this;
    }
    public OrderBuilder withOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
        return this;
    }
    public OrderBuilder withProduct(Getränke product) {
        this.product = product;
        return this;
    }
    public OrderBuilder withOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
        return this;
    }

    public Order build() {
        if (id == null) {
            throw new IllegalArgumentException("id is missing");
        }

        if (orderAmount == null) {
            throw new IllegalArgumentException("order Amount is missing");
        }

        if (orderDate == null) {
            throw new IllegalArgumentException("date is missing");
        }

        if (product == null) {
            throw new IllegalArgumentException("product is missing");
        }
        return new Order(this);
        }
}
}
