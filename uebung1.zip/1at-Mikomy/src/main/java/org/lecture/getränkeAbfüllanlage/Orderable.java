package org.lecture.getränkeAbfüllanlage;

public interface Orderable {
//    void orderProduct() throws InterruptedException;
}
