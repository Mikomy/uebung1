package org.lecture.getränkeAbfüllanlage.cola;

public interface ColaFactory {
    ColaGetränke createColaGetränk(ColaType type);

}
