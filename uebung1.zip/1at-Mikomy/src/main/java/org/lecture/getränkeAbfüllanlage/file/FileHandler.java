package org.lecture.getränkeAbfüllanlage.file;

import lombok.extern.slf4j.Slf4j;
import org.lecture.getränkeAbfüllanlage.Getränke;
import org.lecture.getränkeAbfüllanlage.Order;
import org.lecture.getränkeAbfüllanlage.OrderBook;
import org.lecture.getränkeAbfüllanlage.zitrone.ConcreteZitronen;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenFactory;
import org.lecture.getränkeAbfüllanlage.zitrone.ZitronenType;
import org.lecture.getränkeAbfüllanlage.cola.ConcreteCola;
import org.lecture.getränkeAbfüllanlage.cola.ColaFactory;
import org.lecture.getränkeAbfüllanlage.cola.ColaType;

import java.io.BufferedWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Reads the order File from the given Path
 *
 * @return all read orders
 */

@Slf4j
public class FileHandler {
    private ZitronenFactory zitronenFactory = new ConcreteZitronen();
    private ColaFactory colaFactory = new ConcreteCola();

    private OrderBook orderBook;




    public void saveOrdersInFile(OrderBook orderBook, Path dir) throws IOException {
        Path file = Paths.get(dir.toString(), "savedOrders.csv");
        if (Files.notExists(dir)) {
            Files.createDirectories(dir);
        }

        try (BufferedWriter bw = Files.newBufferedWriter(file)) {
            bw.write("order_id,product,price,order_amount,order_date");
            bw.newLine();

            for (Order order : orderBook.getOrderMap().values()) {
                Getränke productGetränke = (Getränke) order.getProduct();
                BigDecimal orderCost = order.calculateOrderCost();
                String line = order.getId() + "," +
                        productGetränke.getClass().getSimpleName() + "," +
                        productGetränke.getPrice() + "," +
                        order.getOrderAmount() + "," +
                        order.getOrderDate() + "," +
                        orderCost;

                bw.write(line);
                bw.newLine();
            }

            log.debug("Data has been saved in file: " + file);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    /*
    public void saveOrdersInFile(OrderBook orderBook, Path dir) throws IOException {
        Path file = Paths.get(dir.toString(), "savedOrders.csv");
        if (Files.notExists(dir)) {
            Files.createDirectories(dir);
        }
        //  List<Wind> list = windForceBook.getWindForceList();

        try (BufferedWriter bw = Files.newBufferedWriter(file)) {
            bw.write("dateTime,bearing,station,temperature,weather,id,windforce");
            bw.newLine();


            foreach (OrderBook orders : orderBook.getOrderMap()) {
                Order currentOrder = orders.getValue();
                Factory productFactory = (Factory) currentOrder.getProduct();

                String line = (String.valueOf(orders.getDate()) + "," +
                        String.valueOf(orders.getDirection()) + "," +
                        String.valueOf(orders.getStation()) + "," +
                        String.valueOf(orders.getTemperature()) + "," +
                        String.valueOf(orders.getWeather()) + "," +
                        String.valueOf(orders.getId()) + "," +
                        String.valueOf(orders.getWindForce()));
                bw.write(line + "\n");
            }
            log.debug("Data has been saved in file: " + file);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }
    */


}