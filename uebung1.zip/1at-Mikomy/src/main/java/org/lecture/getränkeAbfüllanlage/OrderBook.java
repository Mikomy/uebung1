package org.lecture.getränkeAbfüllanlage;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;
import java.util.TreeMap;

@Setter
@Getter
public class OrderBook {
  //  private List<Orderable> products = new ArrayList<>();
    private Destination destination;
    private final Map<Integer, Order> orderMap = new TreeMap<>();

    public void add(Integer id, Order order) {this.orderMap.put(id, order);}

    // public void addProduct(Orderable product ) { products.add(product); }
    public int size() {
        return orderMap.size();
    }
    public Order remove(int orderId) {
        return orderMap.remove(orderId);
    }
    public void showOrder() {
        System.out.format("%s Order list %s%n", "-".repeat(25), "-".repeat(25));
        for (Map.Entry<Integer, Order> order : orderMap.entrySet() ) {
            Order currentOrder = order.getValue();
            Getränke productGetränke = (Getränke) currentOrder.getProduct();
            System.out.printf("%-5s %-20s %-10s amount: %-20d%n",
                    order.getKey(), productGetränke.getClass().getSimpleName(), productGetränke.getPrice(), currentOrder.getOrderAmount());
        }



        System.out.println("-".repeat(63));
    }
    public void printCosts() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        BigDecimal sum = BigDecimal.ZERO;
        BigDecimal sumPf = BigDecimal.ZERO;
        BigDecimal actuall = BigDecimal.ZERO;

        for (Map.Entry<Integer, Order> order : orderMap.entrySet() ) {
            BigDecimal orderCost = order.getValue().calculateOrderCost();
            BigDecimal pfandCost = order.getValue().calculatePfandCost();

            Order currentOrder = order.getValue();
            Getränke productGetränke = (Getränke) currentOrder.getProduct();
            System.out.printf("~ Kosten %s, bestellt am %s: € %s%n", productGetränke.getClass().getSimpleName(),
                    order.getValue().getOrderDate(), orderCost, pfandCost);
            sum = sum.add(orderCost);
            sumPf = sum.add(pfandCost);
            sum = sum.add(orderCost);
            actuall = sum;
            actuall = actuall.subtract(pfandCost);
        }
        System.out.println();
        System.out.printf("Kosten: € %s%n", sum, sumPf);
        System.out.println("actuall cost: " + actuall);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
    public  Map<Integer, Order> getOrderMap() {
        return this.orderMap;
    }

}
