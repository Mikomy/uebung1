package org.lecture.getränkeAbfüllanlage.soda;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Slf4j
public enum SodaType {
    SODA("Soda", "41");

    SodaType(String name, String orderCode) {
        this.name = name;
        this.orderCode = orderCode;
    }

    private final String name;
    private final String orderCode;

    public String getName() {
        return name;
    }
    public  String getOrderCode() {

        return orderCode;
    }
    public static SodaType checkProductType2(String orderCode) {
        var productType = Arrays.stream(SodaType.values())
                .filter(product -> product.getOrderCode().equalsIgnoreCase(orderCode))
                .findFirst();
        SodaType type = null;
        if (productType.isPresent()) {
            type = productType.get();
        }
        return type;
    }
}
