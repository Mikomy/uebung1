package org.lecture.getränkeAbfüllanlage.zitrone;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConcreteZitronen implements ZitronenFactory {
    @Override
    public ZitronenGetränke createZitronenGetränke(ZitronenType type) {
        ZitronenGetränke product = null;
        switch (type) {
            case ZITRONE -> {
                log.debug("Creating Product");
                product = new Zitrone();
            }
            case ZITRONE_ZUCKERFREI -> {
                log.debug("Creating Product");
                product = new ZitroneZuckerfrei();
            }
            default -> {
                log.error("Unknown Product" + product);
            }
        }
        return product;
    }
}
