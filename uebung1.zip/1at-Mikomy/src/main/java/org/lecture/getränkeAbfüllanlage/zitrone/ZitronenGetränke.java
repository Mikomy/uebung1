package org.lecture.getränkeAbfüllanlage.zitrone;

import lombok.Getter;
import org.lecture.getränkeAbfüllanlage.Getränke;

@Getter
public abstract class ZitronenGetränke extends Getränke {
    protected boolean hasWasser;
    protected boolean hasKohlensäure;
    protected boolean hasZucker;
    protected boolean hasZitronenSaftKonzentrat;


}
