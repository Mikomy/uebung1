package org.lecture.getränkeAbfüllanlage.orangenSaft;

public interface OrangenFactory {
    OrangenGetränke createOrangenGetränk(OrangenType type);

}
