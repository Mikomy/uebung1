package org.lecture.getränkeAbfüllanlage.orangenSaft;

import lombok.Getter;
import org.lecture.getränkeAbfüllanlage.Getränke;

@Getter
public abstract class OrangenGetränke extends Getränke {
    protected boolean hasWasser;
    protected boolean hasZucker;
    protected boolean hasOrangensaft;

}
