package org.lecture.getränkeAbfüllanlage.soda;

import lombok.Getter;
import org.lecture.getränkeAbfüllanlage.Getränke;

@Getter
public abstract class SodaGetränk extends Getränke {
    protected boolean hasWasser;
    protected boolean hasKohlensäure;

}
