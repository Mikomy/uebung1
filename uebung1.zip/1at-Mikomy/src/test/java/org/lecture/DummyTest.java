package org.lecture;

public class DummyTest {
}
