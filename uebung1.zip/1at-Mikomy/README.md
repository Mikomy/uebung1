[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/xWN4_5BZ)
# OPROTemplate

All Dummy-Files can be safely deleted after checkout. They only exist to preserve the correct project structure
